# MERN_STACK_BOOTCAMP_Assignment
Repository for the assignments I am completing during CodeKaro MernStack 6 months Bootcamp 
Description:

Welcome to my repository for the assignments completed during the Code Karo Full Stack Bootcamp. This repository contains a collection of my coding projects and exercises, showcasing my progress and skills in full-stack web development.

Table of Contents:

HTML Assignment: Creating a Simple Blog post. Containing Embeds from youtube and others.

